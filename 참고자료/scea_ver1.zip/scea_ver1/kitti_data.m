switch SeqIdx
    case 1
        Title = '0011';
        FrameSet = 1:31;
        opt.s_size_temp = [10, 0, 10000]; % height size for MOT
        det_name = '0011_car.mat';
end