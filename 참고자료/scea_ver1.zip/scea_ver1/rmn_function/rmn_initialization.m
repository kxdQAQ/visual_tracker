function [RMN, Track] = rmn_initialization(Track,param,f)


for i = 1:length(Track)
    state1 = Track{i}.states;
    frame1 = Track{i}.frame;
    num1 = size(frame1,2);
    lab1 = Track{i}.lab;
    for j = 1:length(Track)
        lab2 = Track{j}.lab;
        if(lab1~=lab2)
            state2 = Track{j}.states;
            frame2 = Track{j}.frame;
            num2 = size(frame2,2);
            RMN(lab1,lab2).set = [];
            
            num_frame = min(num1,num2);
            common_frame = intersect(frame1,frame2);
            flagk = 1;
            for k= 1 : size(common_frame,2)
                f1 = find(frame1==common_frame(k));
                f2 = find(frame2==common_frame(k));
                 s1 = state1(1:2,f1); s2 = state2(1:2,f2);
 
                    if(flagk==1)
                        % initialization
                        [Var] = init_relation_func_Cart(s1,s2);
                        flagk = 0;
                    else
                        % Kalman filtering
                        Dist = s1 - s2;
                        meas = [Dist(1) Dist(2)]';
                        [Var] = KF_prediction_iccv(Var,param.Fr,param.Qr,param.Gr); % Prediction
                        [Var] = KF_update_iccv(meas,Var,param.Rr,param.Hr); % Update
                    end
%                 end
            end
            Var.P = [2 0 0 0;0 2 0 0;0 0 2 0;0 0 0 2].^2;
            Size = [state1(3,end);state2(3,end);state1(4,end);state2(4,end)];
            RMN(lab1,lab2).frames = f;
            RMN(lab1,lab2).set = [RMN(lab1,lab2).set, Var.X];
%             RMN(lab1,lab2).size = Size;
            RMN(lab1,lab2).state = Var; % Relational Function (input lab2-th state, output: lab1-th state)
            Track{i}.graph = [Track{i}.graph, j]; % Graph initialization
            Track{i}.link = [Track{i}.link, j];
        end
    end
end